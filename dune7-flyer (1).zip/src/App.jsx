import { useState } from "react";
import { Dialog } from "@headlessui/react";

export default function App() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">Dune 7 Dental Practice</h1>

      {/* Flyer preview */}
      <img
        src="/flyer.jpg"
        alt="Dune 7 Dental Flyer"
        className="rounded-2xl shadow-lg w-full max-w-lg cursor-pointer hover:opacity-90 transition"
        onClick={() => setIsOpen(true)}
      />

      {/* Lightbox */}
      <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="relative z-50">
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center">
          <Dialog.Panel className="p-4">
            <img
              src="/flyer.jpg"
              alt="Dune 7 Dental Flyer Large"
              className="max-h-[90vh] rounded-lg shadow-2xl"
            />
          </Dialog.Panel>
        </div>
      </Dialog>
    </div>
  );
}